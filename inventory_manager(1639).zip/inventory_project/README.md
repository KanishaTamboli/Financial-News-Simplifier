# Hybrid Inventory Manager

A console-based inventory system that combines a **C data layer** (binary file I/O with `fread`/`fwrite`/`fseek`) and a **C++ UI layer** (classes + STL `vector` + `std::sort`).  
Data persists across restarts in `inventory.dat`.

---

## Project Structure

```
inventory_project/
├── include/
│   ├── inventory.h          # C struct + C-linkage API declarations
│   └── InventoryManager.hpp # C++ class (header-only) wrapping the C API
├── src/
│   ├── inventory.c          # C backend implementation
│   ├── InventoryManager.cpp # Stub (class is header-only)
│   └── main.cpp             # C++ menu / input-validation / driver
├── Makefile
├── CMakeLists.txt
└── README.md
```

---

## Build & Run

### Using Make (recommended)

```bash
# Build
make

# Run
./inventory_manager

# Or build + run in one step
make run

# Clean
make clean
```

### Using CMake

```bash
mkdir -p build_cmake && cd build_cmake
cmake ..
make
./inventory_manager
```

**Requirements:** GCC / G++ with C11 and C++17 support (any modern Linux/macOS).  
Windows users: use WSL or MinGW and run `mingw32-make`.

---

## Features

| # | Option      | Description                                      |
|---|-------------|--------------------------------------------------|
| 1 | Add item    | Stores a new item; rejects duplicate IDs         |
| 2 | View item   | Displays one active item by ID                   |
| 3 | Update item | Modifies name, quantity, price in-place in file  |
| 4 | Delete item | Soft-deletes (hidden from view/list, not erased) |
| 5 | List all    | Shows all active items sorted by ID or name      |
| 6 | Exit        | Quits; data is already flushed to disk           |

### Input Validation
- ID must be a **positive integer** (> 0)  
- Quantity must be **≥ 0**  
- Price must be **≥ 0**  
- Name must be **non-empty**  
- Bad input triggers a re-prompt; the program never crashes on invalid input.

---

## How Persistence Works

Every `add_item` call appends one `sizeof(Item)` binary record to `inventory.dat`.  
`update_item` and `delete_item` use `fseek` to overwrite exactly the right record.  
On the next run the file is re-read from disk — all previously saved state is restored.

---

## Test Cases

- **TC-1 – Persistence after restart**  
  Added items with IDs 1, 2, 3. Exited with option 6. Restarted the program and chose "List all" → all three items appeared with their original names, quantities, and prices. ✅

- **TC-2 – Duplicate ID rejection**  
  Tried to add a second item with ID 2 (already present). The program printed  
  `[!] Failed – ID 2 already exists or file error.` and did not write a duplicate. ✅

- **TC-3 – Update persists after restart**  
  Updated item 1 (changed price from 9.99 to 14.99). Exited, restarted, and used "View item" for ID 1 → price showed 14.99. ✅

- **TC-4 – Soft-delete hides item**  
  Deleted item 2. Chose "List all" → item 2 no longer appeared. Chose "View item" for ID 2 → `[!] Item 2 not found or deleted.` Restarted, repeated both checks → still hidden. ✅

- **TC-5 – Invalid input re-prompts, no crash**  
  Entered `-5` as an ID, then `abc`, then `0`. Each time the program printed the validation message and re-asked. After entering `4` the flow continued normally. ✅
