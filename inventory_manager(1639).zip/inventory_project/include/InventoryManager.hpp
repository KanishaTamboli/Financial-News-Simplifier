#ifndef INVENTORY_MANAGER_HPP
#define INVENTORY_MANAGER_HPP

#include <vector>
#include <string>
#include <algorithm>
#include <iostream>
#include <iomanip>

extern "C" {
#include "inventory.h"
}

/* ------------------------------------------------------------------ */
/*  InventoryManager                                                    */
/* ------------------------------------------------------------------ */

class InventoryManager {
public:
    /* ---------- wrappers around C backend ---------- */

    bool addItem(const Item &item) {
        return add_item(&item) == 1;
    }

    bool getItem(int id, Item &out) {
        return get_item(id, &out) == 1;
    }

    bool updateItem(int id, const Item &updated) {
        return update_item(id, &updated) == 1;
    }

    bool deleteItem(int id) {
        return delete_item(id) == 1;
    }

    /* ---------- list with STL sorting ---------- */

    enum class SortBy { ID, NAME };

    /**
     * Fetch all active items, sort them, and return in a std::vector.
     * Default sort: by ID ascending.
     */
    std::vector<Item> listAll(SortBy by = SortBy::ID) {
        const int MAX = 1024;
        Item raw[MAX];
        int  count = list_items(raw, MAX);

        std::vector<Item> items(raw, raw + count); /* STL element 1 */

        /* STL element 2: std::sort */
        if (by == SortBy::NAME) {
            std::sort(items.begin(), items.end(),
                      [](const Item &a, const Item &b) {
                          return std::string(a.name) < std::string(b.name);
                      });
        } else {
            std::sort(items.begin(), items.end(),
                      [](const Item &a, const Item &b) {
                          return a.id < b.id;
                      });
        }

        return items;
    }

    /* ---------- display helpers ---------- */

    static void printHeader() {
        std::cout << "\n"
                  << std::left
                  << std::setw(6)  << "ID"
                  << std::setw(22) << "Name"
                  << std::setw(10) << "Qty"
                  << std::setw(10) << "Price"
                  << "\n"
                  << std::string(48, '-') << "\n";
    }

    static void printItem(const Item &it) {
        std::cout << std::left
                  << std::setw(6)  << it.id
                  << std::setw(22) << it.name
                  << std::setw(10) << it.quantity
                  << std::fixed << std::setprecision(2)
                  << std::setw(10) << it.price
                  << "\n";
    }

    void printAll(SortBy by = SortBy::ID) {
        auto items = listAll(by);
        if (items.empty()) {
            std::cout << "  (no active items)\n";
            return;
        }
        printHeader();
        for (const auto &it : items) printItem(it);
        std::cout << "\n  " << items.size() << " item(s) found.\n";
    }
};

#endif /* INVENTORY_MANAGER_HPP */
