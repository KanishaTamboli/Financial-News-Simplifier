#ifndef INVENTORY_H
#define INVENTORY_H

#ifdef __cplusplus
extern "C" {
#endif

#define NAME_MAX_LEN 40
#define INVENTORY_FILE "inventory.dat"

typedef struct {
    int   id;
    char  name[NAME_MAX_LEN];
    int   quantity;
    float price;
    int   is_deleted; /* 0 = active, 1 = soft-deleted */
} Item;

/**
 * Add a new item.  Rejects duplicate IDs.
 * Returns 1 on success, 0 on failure.
 */
int add_item(const Item *item);

/**
 * Find an active (non-deleted) item by ID.
 * Copies the record into *out.
 * Returns 1 on success, 0 if not found / deleted.
 */
int get_item(int id, Item *out);

/**
 * Overwrite an existing active record with *updated.
 * Returns 1 on success, 0 if not found / deleted.
 */
int update_item(int id, const Item *updated);

/**
 * Soft-delete an item (sets is_deleted = 1).
 * Returns 1 on success, 0 if not found or already deleted.
 */
int delete_item(int id);

/**
 * Copy up to max_items active records into buffer[].
 * Returns the number of items actually copied.
 */
int list_items(Item *buffer, int max_items);

#ifdef __cplusplus
}
#endif

#endif /* INVENTORY_H */
