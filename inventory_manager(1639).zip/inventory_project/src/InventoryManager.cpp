// InventoryManager is a header-only class (InventoryManager.hpp).
// This file exists so CMake/Make can list it as a translation unit
// without errors.  All logic lives in include/InventoryManager.hpp.
