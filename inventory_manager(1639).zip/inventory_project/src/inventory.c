#include "inventory.h"
#include <stdio.h>
#include <string.h>

/* ------------------------------------------------------------------ */
/*  Internal helpers                                                    */
/* ------------------------------------------------------------------ */

/** Return the byte offset of record index i inside the file. */
static long record_offset(int index)
{
    return (long)index * (long)sizeof(Item);
}

/**
 * Scan the file for an item matching `id`.
 * If found, store its file index in *idx and the record in *out (may be NULL).
 * Returns 1 if found (regardless of is_deleted), 0 otherwise.
 */
static int find_record(int id, int *idx, Item *out)
{
    FILE *fp = fopen(INVENTORY_FILE, "rb");
    if (!fp) return 0;

    Item tmp;
    int  index = 0;
    int  found = 0;

    while (fread(&tmp, sizeof(Item), 1, fp) == 1) {
        if (tmp.id == id) {
            found = 1;
            if (idx) *idx = index;
            if (out) *out = tmp;
            break;
        }
        index++;
    }

    fclose(fp);
    return found;
}

/* ------------------------------------------------------------------ */
/*  Public API                                                          */
/* ------------------------------------------------------------------ */

int add_item(const Item *item)
{
    if (!item) return 0;

    /* Reject duplicate ID */
    if (find_record(item->id, NULL, NULL)) return 0;

    FILE *fp = fopen(INVENTORY_FILE, "ab");
    if (!fp) return 0;

    int ok = (fwrite(item, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

int get_item(int id, Item *out)
{
    if (!out) return 0;

    Item tmp;
    if (!find_record(id, NULL, &tmp)) return 0;
    if (tmp.is_deleted) return 0;

    *out = tmp;
    return 1;
}

int update_item(int id, const Item *updated)
{
    if (!updated) return 0;

    int  idx;
    Item tmp;
    if (!find_record(id, &idx, &tmp)) return 0;
    if (tmp.is_deleted) return 0;

    /* Open for read+write without truncating */
    FILE *fp = fopen(INVENTORY_FILE, "r+b");
    if (!fp) return 0;

    fseek(fp, record_offset(idx), SEEK_SET);
    int ok = (fwrite(updated, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

int delete_item(int id)
{
    int  idx;
    Item tmp;
    if (!find_record(id, &idx, &tmp)) return 0;
    if (tmp.is_deleted) return 0; /* already deleted */

    tmp.is_deleted = 1;

    FILE *fp = fopen(INVENTORY_FILE, "r+b");
    if (!fp) return 0;

    fseek(fp, record_offset(idx), SEEK_SET);
    int ok = (fwrite(&tmp, sizeof(Item), 1, fp) == 1);
    fclose(fp);
    return ok;
}

int list_items(Item *buffer, int max_items)
{
    if (!buffer || max_items <= 0) return 0;

    FILE *fp = fopen(INVENTORY_FILE, "rb");
    if (!fp) return 0;

    Item tmp;
    int  count = 0;

    while (count < max_items && fread(&tmp, sizeof(Item), 1, fp) == 1) {
        if (!tmp.is_deleted) {
            buffer[count++] = tmp;
        }
    }

    fclose(fp);
    return count;
}
