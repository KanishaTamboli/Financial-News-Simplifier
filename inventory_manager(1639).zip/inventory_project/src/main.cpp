#include <iostream>
#include <limits>
#include <cstring>
#include "InventoryManager.hpp"

/* ------------------------------------------------------------------ */
/*  Input validation helpers                                            */
/* ------------------------------------------------------------------ */

/** Read a positive integer (> 0). Re-prompts on bad input. */
static int readPositiveInt(const std::string &prompt)
{
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val > 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cout << "  [!] Invalid – enter a positive integer.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

/** Read an integer >= 0.  Re-prompts on bad input. */
static int readNonNegInt(const std::string &prompt)
{
    int val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cout << "  [!] Invalid – enter 0 or a positive integer.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

/** Read a float >= 0.  Re-prompts on bad input. */
static float readNonNegFloat(const std::string &prompt)
{
    float val;
    while (true) {
        std::cout << prompt;
        if (std::cin >> val && val >= 0.0f) {
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            return val;
        }
        std::cout << "  [!] Invalid – enter 0 or a positive number.\n";
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }
}

/** Read a non-empty name string. Re-prompts if blank. */
static std::string readName(const std::string &prompt)
{
    std::string val;
    while (true) {
        std::cout << prompt;
        std::getline(std::cin, val);
        if (!val.empty()) return val;
        std::cout << "  [!] Name must not be empty.\n";
    }
}

/* ------------------------------------------------------------------ */
/*  Menu actions                                                        */
/* ------------------------------------------------------------------ */

static void doAdd(InventoryManager &mgr)
{
    std::cout << "\n--- Add Item ---\n";
    Item it{};

    it.id       = readPositiveInt("  Item ID      : ");
    std::string nm = readName("  Name         : ");
    std::strncpy(it.name, nm.c_str(), NAME_MAX_LEN - 1);
    it.name[NAME_MAX_LEN - 1] = '\0';
    it.quantity = readNonNegInt("  Quantity     : ");
    it.price    = readNonNegFloat("  Price        : ");
    it.is_deleted = 0;

    if (mgr.addItem(it))
        std::cout << "  [OK] Item " << it.id << " added.\n";
    else
        std::cout << "  [!] Failed – ID " << it.id << " already exists or file error.\n";
}

static void doView(InventoryManager &mgr)
{
    std::cout << "\n--- View Item ---\n";
    int id = readPositiveInt("  Item ID: ");
    Item it{};
    if (mgr.getItem(id, it)) {
        InventoryManager::printHeader();
        InventoryManager::printItem(it);
    } else {
        std::cout << "  [!] Item " << id << " not found or deleted.\n";
    }
}

static void doUpdate(InventoryManager &mgr)
{
    std::cout << "\n--- Update Item ---\n";
    int id = readPositiveInt("  Item ID to update: ");

    Item existing{};
    if (!mgr.getItem(id, existing)) {
        std::cout << "  [!] Item " << id << " not found or deleted.\n";
        return;
    }

    std::cout << "  Current values – Name: " << existing.name
              << "  Qty: "   << existing.quantity
              << "  Price: " << existing.price << "\n";
    std::cout << "  (Press Enter to keep current value where shown)\n";

    /* New name */
    std::cout << "  New name [" << existing.name << "]: ";
    std::string nm;
    std::getline(std::cin, nm);
    if (!nm.empty())
        std::strncpy(existing.name, nm.c_str(), NAME_MAX_LEN - 1);
    existing.name[NAME_MAX_LEN - 1] = '\0';

    existing.quantity = readNonNegInt("  New quantity  : ");
    existing.price    = readNonNegFloat("  New price     : ");

    if (mgr.updateItem(id, existing))
        std::cout << "  [OK] Item " << id << " updated.\n";
    else
        std::cout << "  [!] Update failed.\n";
}

static void doDelete(InventoryManager &mgr)
{
    std::cout << "\n--- Delete Item ---\n";
    int id = readPositiveInt("  Item ID to delete: ");

    std::cout << "  Are you sure? (y/N): ";
    std::string confirm;
    std::getline(std::cin, confirm);
    if (confirm != "y" && confirm != "Y") {
        std::cout << "  Cancelled.\n";
        return;
    }

    if (mgr.deleteItem(id))
        std::cout << "  [OK] Item " << id << " deleted.\n";
    else
        std::cout << "  [!] Item " << id << " not found or already deleted.\n";
}

static void doList(InventoryManager &mgr)
{
    std::cout << "\n--- List All Items ---\n";
    std::cout << "  Sort by: (1) ID  (2) Name [1]: ";
    std::string choice;
    std::getline(std::cin, choice);

    InventoryManager::SortBy by = (choice == "2")
        ? InventoryManager::SortBy::NAME
        : InventoryManager::SortBy::ID;

    mgr.printAll(by);
}

/* ------------------------------------------------------------------ */
/*  main                                                                */
/* ------------------------------------------------------------------ */

int main()
{
    InventoryManager mgr;

    std::cout << "========================================\n";
    std::cout << "        Hybrid Inventory Manager        \n";
    std::cout << "========================================\n";

    while (true) {
        std::cout << "\n"
                  << "  1. Add item\n"
                  << "  2. View item\n"
                  << "  3. Update item\n"
                  << "  4. Delete item\n"
                  << "  5. List all\n"
                  << "  6. Exit\n"
                  << "\n"
                  << "Choice: ";

        std::string line;
        std::getline(std::cin, line);

        if (line.empty()) continue;

        switch (line[0]) {
            case '1': doAdd(mgr);    break;
            case '2': doView(mgr);   break;
            case '3': doUpdate(mgr); break;
            case '4': doDelete(mgr); break;
            case '5': doList(mgr);   break;
            case '6':
                std::cout << "  Goodbye!\n";
                return 0;
            default:
                std::cout << "  [!] Invalid choice – enter 1–6.\n";
        }
    }
}
